import React, { useState } from 'react';
import { Upload, FileWarning, Brain, Stethoscope, MessageCircle, Send, X, FileOutput, Phone, AlertCircle } from 'lucide-react';

type ImageType = 'mri' | 'mammogram';
type AnalysisStatus = 'idle' | 'uploading' | 'analyzing' | 'complete';
type Gender = 'male' | 'female' | 'other';

interface Message {
  text: string;
  isUser: boolean;
}

interface UserInfo {
  fullName: string;
  age: number;
  gender: Gender;
  email: string;
}

interface BrainTumorInfo {
  frequentHeadaches: string;
  visionProblems: boolean;
  memoryLoss: boolean;
  nauseaVomiting: boolean;
  seizures: boolean;
  weaknessNumbness: boolean;
  balanceDizziness: boolean;
  familyHistory: boolean;
  radiationExposure: boolean;
  headTrauma: boolean;
  neurologicalDisorder: boolean;
}

interface BreastCancerInfo {
  lumpThickening: boolean;
  breastPain: boolean;
  sizeShapeChanges: boolean;
  nippleDischarge: boolean;
  skinChanges: boolean;
  familyHistory: boolean;
  hormoneTherapy: boolean;
  abnormalTissue: boolean;
  alcoholConsumption: boolean;
  hadChildren: string;
  firstPeriodAge: number;
  menopauseAge: number | null;
}

const initialUserInfo: UserInfo = {
  fullName: '',
  age: 0,
  gender: 'male',
  email: '',
};

const initialBrainTumorInfo: BrainTumorInfo = {
  frequentHeadaches: 'no',
  visionProblems: false,
  memoryLoss: false,
  nauseaVomiting: false,
  seizures: false,
  weaknessNumbness: false,
  balanceDizziness: false,
  familyHistory: false,
  radiationExposure: false,
  headTrauma: false,
  neurologicalDisorder: false,
};

const initialBreastCancerInfo: BreastCancerInfo = {
  lumpThickening: false,
  breastPain: false,
  sizeShapeChanges: false,
  nippleDischarge: false,
  skinChanges: false,
  familyHistory: false,
  hormoneTherapy: false,
  abnormalTissue: false,
  alcoholConsumption: false,
  hadChildren: 'no',
  firstPeriodAge: 0,
  menopauseAge: null,
};

const chatbotResponses = {
  brainTumor: {
    symptoms: "Common brain tumor symptoms include headaches, seizures, changes in personality, and vision problems. If you experience these symptoms, please consult a healthcare provider.",
    prevention: "While brain tumors can't always be prevented, maintaining a healthy lifestyle, avoiding radiation exposure, and regular check-ups can help with early detection.",
    treatment: "Treatment options may include surgery, radiation therapy, chemotherapy, or a combination. The specific treatment plan depends on tumor type, size, and location.",
  },
  breastCancer: {
    symptoms: "Common breast cancer signs include lumps, changes in breast size/shape, skin changes, and nipple discharge. Regular self-exams and mammograms are important for early detection.",
    prevention: "Maintain a healthy weight, exercise regularly, limit alcohol, don't smoke, and get regular screenings. Consider genetic testing if you have a family history.",
    treatment: "Treatment options include surgery (lumpectomy/mastectomy), radiation therapy, chemotherapy, hormone therapy, and targeted therapy.",
  },
  general: {
    checkup: "Regular medical check-ups are essential for early detection. Schedule annual screenings with your healthcare provider.",
    emergency: "If you're experiencing severe symptoms, please seek immediate medical attention or contact your healthcare provider.",
    lifestyle: "Maintain a healthy lifestyle with regular exercise, balanced diet, adequate sleep, and stress management.",
  }
};

function getChatbotResponse(input: string): string {
  const lowerInput = input.toLowerCase();
  
  if (lowerInput.includes('brain') && lowerInput.includes('symptom')) {
    return chatbotResponses.brainTumor.symptoms;
  } else if (lowerInput.includes('brain') && lowerInput.includes('prevent')) {
    return chatbotResponses.brainTumor.prevention;
  } else if (lowerInput.includes('brain') && lowerInput.includes('treat')) {
    return chatbotResponses.brainTumor.treatment;
  } else if (lowerInput.includes('breast') && lowerInput.includes('symptom')) {
    return chatbotResponses.breastCancer.symptoms;
  } else if (lowerInput.includes('breast') && lowerInput.includes('prevent')) {
    return chatbotResponses.breastCancer.prevention;
  } else if (lowerInput.includes('breast') && lowerInput.includes('treat')) {
    return chatbotResponses.breastCancer.treatment;
  } else if (lowerInput.includes('checkup') || lowerInput.includes('screening')) {
    return chatbotResponses.general.checkup;
  } else if (lowerInput.includes('emergency') || lowerInput.includes('urgent')) {
    return chatbotResponses.general.emergency;
  } else if (lowerInput.includes('lifestyle') || lowerInput.includes('health')) {
    return chatbotResponses.general.lifestyle;
  }
  
  return "I can provide information about brain tumor and breast cancer symptoms, prevention, and treatment. Please ask specific questions about these topics.";
}

function getRecommendations(
  imageType: ImageType,
  diagnosis: string,
  userInfo: UserInfo,
  brainInfo: BrainTumorInfo,
  breastInfo: BreastCancerInfo
): string[] {
  const recommendations: string[] = [];
  const age = userInfo.age;

  if (imageType === 'mri') {
    if (diagnosis === 'healthy') {
      recommendations.push("Your brain MRI shows no significant abnormalities.");
      
      if (brainInfo.frequentHeadaches !== 'no' || brainInfo.visionProblems || brainInfo.memoryLoss) {
        recommendations.push("Although your MRI is normal, your symptoms warrant further investigation. Consider consulting a neurologist.");
      }
      
      if (age >= 50) {
        recommendations.push("Given your age, we recommend annual neurological check-ups.");
      }
      
      if (brainInfo.familyHistory) {
        recommendations.push("Due to your family history, consider genetic counseling and regular screenings.");
      }
    } else {
      recommendations.push("⚠️ Abnormalities detected in your brain MRI scan.");
      recommendations.push("Immediate consultation with a neurosurgeon is strongly recommended.");
      
      if (brainInfo.seizures || brainInfo.weaknessNumbness) {
        recommendations.push("Your symptoms suggest active neurological issues. Emergency medical evaluation is advised.");
      }
      
      recommendations.push("Additional diagnostic tests may include:");
      recommendations.push("- Contrast-enhanced MRI");
      recommendations.push("- Functional MRI (fMRI)");
      recommendations.push("- Spectroscopy");
    }
  } else {
    if (diagnosis === 'healthy') {
      recommendations.push("Your mammogram shows no signs of breast cancer.");
      
      if (age >= 40) {
        recommendations.push("Continue with annual mammogram screenings.");
      } else {
        recommendations.push("Follow recommended screening guidelines for your age group.");
      }
      
      if (breastInfo.familyHistory) {
        recommendations.push("Due to your family history, consider:");
        recommendations.push("- Genetic testing for BRCA1/BRCA2 mutations");
        recommendations.push("- More frequent screenings");
      }
    } else {
      recommendations.push("⚠️ Abnormalities detected in your mammogram.");
      recommendations.push("Urgent consultation with a breast specialist is required.");
      
      if (breastInfo.lumpThickening || breastInfo.nippleDischarge) {
        recommendations.push("Your symptoms combined with imaging results require immediate attention.");
      }
      
      recommendations.push("Recommended follow-up tests:");
      recommendations.push("- Diagnostic mammogram");
      recommendations.push("- Breast ultrasound");
      recommendations.push("- Possible biopsy");
    }
  }

  recommendations.push("\nGeneral Health Recommendations:");
  recommendations.push("- Maintain a healthy diet rich in antioxidants");
  recommendations.push("- Regular exercise (at least 150 minutes per week)");
  recommendations.push("- Adequate sleep (7-9 hours per night)");
  recommendations.push("- Stress management techniques");
  
  return recommendations;
}

function App() {
  const [imageType, setImageType] = useState<ImageType>('mri');
  const [status, setStatus] = useState<AnalysisStatus>('idle');
  const [file, setFile] = useState<File | null>(null);
  const [showChat, setShowChat] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      text: "Hello! I'm your medical assistant. I can answer questions about brain tumors and breast cancer. How can I help you today?",
      isUser: false
    }
  ]);
  const [currentMessage, setCurrentMessage] = useState('');
  const [userInfo, setUserInfo] = useState<UserInfo>(initialUserInfo);
  const [brainTumorInfo, setBrainTumorInfo] = useState<BrainTumorInfo>(initialBrainTumorInfo);
  const [breastCancerInfo, setBreastCancerInfo] = useState<BreastCancerInfo>(initialBreastCancerInfo);
  const [diagnosis, setDiagnosis] = useState<string>('');
  const [recommendations, setRecommendations] = useState<string[]>([]);
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      setFile(selectedFile);
      setStatus('uploading');
      setTimeout(() => {
        setStatus('analyzing');
        setTimeout(() => {
          const simulatedDiagnosis = Math.random() > 0.7 ? 'abnormal' : 'healthy';
          setDiagnosis(simulatedDiagnosis);
          setRecommendations(getRecommendations(
            imageType,
            simulatedDiagnosis,
            userInfo,
            brainTumorInfo,
            breastCancerInfo
          ));
          setStatus('complete');
        }, 2000);
      }, 1500);
    }
  };

  const analyzeFormData = () => {
    setStatus('analyzing');
    setTimeout(() => {
      let newDiagnosis = 'healthy';
      
      if (imageType === 'mri') {
        const riskFactors = [
          brainTumorInfo.frequentHeadaches !== 'no',
          brainTumorInfo.visionProblems,
          brainTumorInfo.memoryLoss,
          brainTumorInfo.nauseaVomiting,
          brainTumorInfo.seizures,
          brainTumorInfo.weaknessNumbness,
          brainTumorInfo.familyHistory
        ].filter(Boolean).length;

        newDiagnosis = riskFactors >= 3 ? 'abnormal' : 'healthy';
      } else {
        const riskFactors = [
          breastCancerInfo.lumpThickening,
          breastCancerInfo.nippleDischarge,
          breastCancerInfo.skinChanges,
          breastCancerInfo.familyHistory,
          breastCancerInfo.abnormalTissue,
          breastCancerInfo.hormoneTherapy
        ].filter(Boolean).length;

        newDiagnosis = riskFactors >= 2 ? 'abnormal' : 'healthy';
      }

      setDiagnosis(newDiagnosis);
      setRecommendations(getRecommendations(
        imageType,
        newDiagnosis,
        userInfo,
        brainTumorInfo,
        breastCancerInfo
      ));
      setStatus('complete');
    }, 2000);
  };

  const handleSendMessage = () => {
    if (currentMessage.trim()) {
      const newMessages = [
        ...messages,
        { text: currentMessage, isUser: true },
        { text: getChatbotResponse(currentMessage), isUser: false }
      ];
      setMessages(newMessages);
      setCurrentMessage('');
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const isFormValid = () => {
    if (!userInfo.fullName || !userInfo.email || userInfo.age < 1) {
      return false;
    }

    if (imageType === 'mri') {
      return brainTumorInfo.frequentHeadaches !== '';
    } else {
      return breastCancerInfo.firstPeriodAge > 0;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100 flex flex-col">
      <header className="bg-white shadow-sm">
        <div className="w-full px-4 py-4 sm:px-6 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Stethoscope className="h-8 w-8 text-blue-600" />
            <h1 className="text-2xl font-semibold text-gray-900">MedAi</h1>
          </div>
          <div className="flex items-center space-x-4">
            <select
              value={imageType}
              onChange={(e) => setImageType(e.target.value as ImageType)}
              className="rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            >
              <option value="mri">Brain MRI</option>
              <option value="mammogram">Mammogram</option>
            </select>
            <button
              onClick={() => setShowChat(!showChat)}
              className="inline-flex items-center px-3 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
            >
              <MessageCircle className="h-5 w-5 mr-2" />
              Chat
            </button>
          </div>
        </div>
      </header>

      <main className="flex-1 w-full px-4 py-8">
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <h2 className="text-xl font-semibold text-gray-900 mb-6">Patient Information</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <div>
              <label className="block text-sm font-medium text-gray-700">Full Name</label>
              <input
                type="text"
                value={userInfo.fullName}
                onChange={(e) => setUserInfo({...userInfo, fullName: e.target.value})}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">Age</label>
              <input
                type="number"
                value={userInfo.age || ''}
                onChange={(e) => setUserInfo({...userInfo, age: parseInt(e.target.value)})}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">Gender</label>
              <select
                value={userInfo.gender}
                onChange={(e) => setUserInfo({...userInfo, gender: e.target.value as Gender})}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              >
                <option value="male">Male</option>
                <option value="female">Female</option>
                <option value="other">Other</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">Email</label>
              <input
                type="email"
                value={userInfo.email}
                onChange={(e) => setUserInfo({...userInfo, email: e.target.value})}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              />
            </div>
          </div>

          {imageType === 'mri' ? (
            <div className="space-y-6">
              <h3 className="text-lg font-medium text-gray-900">Brain Tumor Assessment</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Frequent Headaches</label>
                  <select
                    value={brainTumorInfo.frequentHeadaches}
                    onChange={(e) => setBrainTumorInfo({...brainTumorInfo, frequentHeadaches: e.target.value})}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  >
                    <option value="no">No</option>
                    <option value="yes">Yes</option>
                    <option value="sometimes">Sometimes</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700">Vision Problems</label>
                  <select
                    value={brainTumorInfo.visionProblems.toString()}
                    onChange={(e) => setBrainTumorInfo({...brainTumorInfo, visionProblems: e.target.value === 'true'})}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  >
                    <option value="false">No</option>
                    <option value="true">Yes</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Memory Loss or Confusion</label>
                  <select
                    value={brainTumorInfo.memoryLoss.toString()}
                    onChange={(e) => setBrainTumorInfo({...brainTumorInfo, memoryLoss: e.target.value === 'true'})}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  >
                    <option value="false">No</option>
                    <option value="true">Yes</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Nausea or Vomiting</label>
                  <select
                    value={brainTumorInfo.nauseaVomiting.toString()}
                    onChange={(e) => setBrainTumorInfo({...brainTumorInfo, nauseaVomiting: e.target.value === 'true'})}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  >
                    <option value="false">No</option>
                    <option value="true">Yes</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Seizures</label>
                  <select
                    value={brainTumorInfo.seizures.toString()}
                    onChange={(e) => setBrainTumorInfo({...brainTumorInfo, seizures: e.target.value === 'true'})}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  >
                    <option value="false">No</option>
                    <option value="true">Yes</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Weakness or Numbness</label>
                  <select
                    value={brainTumorInfo.weaknessNumbness.toString()}
                    onChange={(e) => setBrainTumorInfo({...brainTumorInfo, weaknessNumbness: e.target.value === 'true'})}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  >
                    <option value="false">No</option>
                    <option value="true">Yes</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Balance Problems or Dizziness</label>
                  <select
                    value={brainTumorInfo.balanceDizziness.toString()}
                    onChange={(e) => setBrainTumorInfo({...brainTumorInfo, balanceDizziness: e.target.value === 'true'})}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  >
                    <option value="false">No</option>
                    <option value="true">Yes</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Family History of Brain Tumors</label>
                  <select
                    value={brainTumorInfo.familyHistory.toString()}
                    onChange={(e) => setBrainTumorInfo({...brainTumorInfo, familyHistory: e.target.value === 'true'})}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  >
                    <option value="false">No</option>
                    <option value="true">Yes</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">History of Radiation Exposure</label>
                  <select
                    value={brainTumorInfo.radiationExposure.toString()}
                    onChange={(e) => setBrainTumorInfo({...brainTumorInfo, radiationExposure: e.target.value === 'true'})}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  >
                    <option value="false">No</option>
                    <option value="true">Yes</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Previous Head Trauma</label>
                  <select
                    value={brainTumorInfo.headTrauma.toString()}
                    onChange={(e) => setBrainTumorInfo({...brainTumorInfo, headTrauma: e.target.value === 'true'})}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  >
                    <option value="false">No</option>
                    <option value="true">Yes</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Pre-existing Neurological Disorder</label>
                  <select
                    value={brainTumorInfo.neurologicalDisorder.toString()}
                    onChange={(e) => setBrainTumorInfo({...brainTumorInfo, neurologicalDisorder: e.target.value === 'true'})}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  >
                    <option value="false">No</option>
                    <option value="true">Yes</option>
                  </select>
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-6">
              <h3 className="text-lg font-medium text-gray-900">Breast Cancer Assessment</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Breast Lump or Thickening</label>
                  <select
                    value={breastCancerInfo.lumpThickening.toString()}
                    onChange={(e) => setBreastCancerInfo({...breastCancerInfo, lumpThickening: e.target.value === 'true'})}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  >
                    <option value="false">No</option>
                    <option value="true">Yes</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Breast Pain</label>
                  <select
                    value={breastCancerInfo.breastPain.toString()}
                    onChange={(e) => setBreastCancerInfo({...breastCancerInfo, breastPain: e.target.value === 'true'})}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  >
                    <option value="false">No</option>
                    <option value="true">Yes</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Changes in Size or Shape</label>
                  <select
                    value={breastCancerInfo.sizeShapeChanges.toString()}
                    onChange={(e) => setBreastCancerInfo({...breastCancerInfo, sizeShapeChanges: e.target.value === 'true'})}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  >
                    <option value="false">No</option>
                    <option value="true">Yes</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Nipple Discharge</label>
                  <select
                    value={breastCancerInfo.nippleDischarge.toString()}
                    onChange={(e) => setBreastCancerInfo({...breastCancerInfo, nippleDischarge: e.target.value === 'true'})}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  >
                    <option value="false">No</option>
                    <option value="true">Yes</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Skin Changes</label>
                  <select
                    value={breastCancerInfo.skinChanges.toString()}
                    onChange={(e) => setBreastCancerInfo({...breastCancerInfo, skinChanges: e.target.value === 'true'})}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  >
                    <option value="false">No</option>
                    <option value="true">Yes</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Family History of Breast Cancer</label>
                  <select
                    value={breastCancerInfo.familyHistory.toString()}
                    onChange={(e) => setBreastCancerInfo({...breastCancerInfo, familyHistory: e.target.value === 'true'})}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  >
                    <option value="false">No</option>
                    <option value="true">Yes</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Hormone Replacement Therapy</label>
                  <select
                    value={breastCancerInfo.hormoneTherapy.toString()}
                    onChange={(e) => setBreastCancerInfo({...breastCancerInfo, hormoneTherapy: e.target.value === 'true'})}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  >
                    <option value="false">No</option>
                    <option value="true">Yes</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Previous Abnormal Breast Tissue</label>
                  <select
                    value={breastCancerInfo.abnormalTissue.toString()}
                    onChange={(e) => setBreastCancerInfo({...breastCancerInfo, abnormalTissue: e.target.value === 'true'})}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  >
                    <option value="false">No</option>
                    <option value="true">Yes</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Regular Alcohol Consumption</label>
                  <select
                    value={breastCancerInfo.alcoholConsumption.toString()}
                    onChange={(e) => setBreastCancerInfo({...breastCancerInfo, alcoholConsumption: e.target.value === 'true'})}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  >
                    <option value="false">No</option>
                    <option value="true">Yes</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Have Children</label>
                  <select
                    value={breastCancerInfo.hadChildren}
                    onChange={(e) => setBreastCancerInfo({...breastCancerInfo, hadChildren: e.target.value})}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  >
                    <option value="no">No</option>
                    <option value="yes">Yes</option>
                    <option value="not_applicable">Not Applicable</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Age at First Period</label>
                  <input
                    type="number"
                    value={breastCancerInfo.firstPeriodAge || ''}
                    onChange={(e) => setBreastCancerInfo({...breastCancerInfo, firstPeriodAge: parseInt(e.target.value)})}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Age at Menopause (if applicable)</label>
                  <input
                    type="number"
                    value={breastCancerInfo.menopauseAge || ''}
                    onChange={(e) => setBreastCancerInfo({...breastCancerInfo, menopauseAge: parseInt(e.target.value)})}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <div className="max-w-full mx-auto text-center">
            <div className="mb-6">
              {status === 'idle' && <Upload className="mx-auto h-12 w-12 text-gray-400" />}
              {status === 'uploading' && <FileWarning className="mx-auto h-12 w-12 text-yellow-400 animate-pulse" />}
              {status === 'analyzing' && <Brain className="mx-auto h-12 w-12 text-blue-500 animate-pulse" />}
              {status === 'complete' && <FileOutput className="mx-auto h-12 w-12 text-green-500" />}
            </div>
            
            <h2 className="text-xl font-semibold text-gray-900 mb-2">
              {imageType === 'mri' ? 'Brain MRI Analysis' : 'Mammogram Analysis'}
            </h2>
            
            <p className="text-gray-600 mb-6">
              Complete the form above and optionally upload a {imageType === 'mri' ? 'brain MRI scan' : 'mammogram'} for enhanced analysis
            </p>

            {status === 'idle' && (
              <div className="space-y-4">
                <button
                  onClick={analyzeFormData}
                  disabled={!isFormValid()}
                  className={`w-full inline-flex justify-center items-center px-4 py-2 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 ${
                    !isFormValid() ? 'opacity-50 cursor-not-allowed' : ''
                  }`}
                >
                  Analyze Form Data
                </button>

                <div className="relative">
                  <div className="absolute inset-0 flex items-center">
                    <div className="w-full border-t border-gray-300"></div>
                  </div>
                  <div className="relative flex justify-center text-sm">
                    <span className="px-2 bg-white text-gray-500">Or</span>
                  </div>
                </div>

                <label className={`inline-flex justify-center w-full items-center px-4 py-2 border border-gray-300 text-base font-medium rounded-md shadow-sm text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 cursor-pointer ${
                  !isFormValid() ? 'opacity-50 cursor-not-allowed' : ''
                }`}>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleFileChange}
                    className="hidden"
                    disabled={!isFormValid()}
                  />
                  Upload Image for Enhanced Analysis
                </label>
              </div>
            )}

            {(status === 'uploading' || status === 'analyzing') && (
              <div className="flex flex-col items-center space-y-4">
                <div className="w-full max-w-xs bg-gray-200 rounded-full h-2.5">
                  <div 
                    className="bg-blue-600 h-2.5 rounded-full transition-all duration-500"
                    style={{ width: status === 'uploading' ? '30%' : '70%' }}
                  ></div>
                </div>
                <p className="text-sm text-gray-600">
                  {status === 'uploading' ? 'Uploading image...' : 'Analyzing image...'}
                </p>
              </div>
            )}

            {status === 'complete' && (
              <div className="space-y-6">
                <div className="bg-white border border-gray-200 rounded-lg p-6">
                  <h3 className="text-lg font-medium text-gray-900 mb-4">Analysis Results</h3>
                  <div className="space-y-4">
                    <div className="flex justify-between py-2 border-b">
                      <span className="text-gray-600">Image Type</span>
                      <span className="font-medium">{imageType === 'mri' ? 'Brain MRI' : 'Mammogram'}</span>
                    </div>
                    <div className="flex justify-between py-2 border-b">
                      <span className="text-gray-600">Patient Name</span>
                      <span className="font-medium">{userInfo.fullName}</span>
                    </div>
                    <div className="flex justify-between py-2 border-b">
                      <span className="text-gray-600">Analysis Status</span>
                      <span className="font-medium text-green-600">Complete</span>
                    </div>
                    <div className="flex justify-between py-2 border-b">
                      <span className="text-gray-600">Confidence Score</span>
                      <span className="font-medium">98.5%</span>
                    </div>
                    <div className="flex justify-between py-2">
                      <span className="text-gray-600">Diagnosis</span>
                      <span className={`font-medium ${diagnosis === 'healthy' ? 'text-green-600' : 'text-red-600'}`}>
                        {diagnosis === 'healthy' ? 'No abnormalities detected' : 'Abnormalities detected'}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="bg-white border border-gray-200 rounded-lg p-6">
                  <h3 className="text-lg font-medium text-gray-900 mb-4">Recommendations</h3>
                  <div className="space-y-2">
                    {recommendations.map((recommendation, index) => (
                      <p key={index} className="text-gray-700">
                        {recommendation}
                      </p>
                    ))}
                  </div>
                </div>

                <button
                  onClick={() => setStatus('idle')}
                  className="inline-flex items-center px-4 py-2 border border-transparent text-base font-medium rounded-md text-blue-700 bg-blue-100 hover:bg-blue-200"
                >
                  Analyze Another Image
                </button>
              </div>
            )}
          </div>
        </div>

        {showChat && (
          <div className="fixed bottom-4 right-4 w-96 h-[500px] bg-white rounded-lg shadow-xl flex flex-col">
            <div className="p-4 border-b flex justify-between items-center bg-blue-600 text-white rounded-t-lg">
              <div className="flex items-center space-x-2">
                <MessageCircle className="h-5 w-5" />
                <span className="font-medium">Medical Assistant</span>
              </div>
              <button onClick={() => setShowChat(false)} className="text-white hover:text-gray-200">
                <X className="h-5 w-5" />
              </button>
            </div>
            
            <div className="flex-1 p-4 overflow-y-auto space-y-4">
              {messages.map((message, index) => (
                <div key={index} className={`flex ${message.isUser ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[80%] p-3 rounded-lg ${
                    message.isUser 
                      ? 'bg-blue-600 text-white rounded-br-none' 
                      : 'bg-gray-100 text-gray-800 rounded-bl-none'
                  }`}>
                    {message.text}
                  </div>
                </div>
              ))}
            </div>
            
            <div className="p-4 border-t space-y-4">
              <a
                href="tel:+916381269983"
                className="flex items-center justify-center w-full px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-red-600 hover:bg-red-700 transition-colors"
              >
                <AlertCircle className="h-4 w-4 mr-2" />
                Emergency Call
              </a>
              <div className="flex space-x-2">
                <input
                  type="text"
                  value={currentMessage}
                  onChange={(e) => setCurrentMessage(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Ask about symptoms, prevention, or treatment..."
                  className="flex-1 rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                />
                <button
                  onClick={handleSendMessage}
                  className="inline-flex items-center px-3 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
                >
                  <Send className="h-4 w-4" />
                </button>
              </div>
            </div>
          </div>
        )}
      </main>

      <footer className="bg-white border-t">
        <div className="w-full px-4 py-6">
          <div className="flex justify-between items-center">
            <p className="text-gray-500 text-sm">
              © 2025 MedImage Analysis. For medical emergencies, please call emergency services.
            </p>
            <a
              href="tel:+916381269983"
              className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-red-600 hover:bg-red-700 transition-colors"
            >
              <Phone className="h-4 w-4 mr-2" />
              Emergency Call
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;